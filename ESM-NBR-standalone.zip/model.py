# -*- coding: UTF-8 -*-
'''=================================================
@Project -> ContactCry    ：FWorks -> model
@IDE    ：PyCharm
@Author : wenwuZeng
@Date   ：2023/7/20 15:34
=================================================='''

import torch
import torch.nn as nn

class ESM_NBR(nn.Module):
    def __init__(self,input_size,hidden_size,num_layers):
        super(ESM_NBR,self).__init__()

        self.LSTM = nn.LSTM(
            input_size=input_size,
            hidden_size=hidden_size,
            bidirectional=True,
            batch_first=True,
            dropout=0.5,
            num_layers=num_layers
        )

        self.fc1=nn.Sequential(
            nn.Linear(hidden_size * 2, 500),
            nn.Dropout(0.5),
            nn.LayerNorm(500),
            nn.ReLU(),
        )

        self.fc2=nn.Sequential(
            nn.Linear(500, 300),
            nn.Dropout(0.5),
            nn.LayerNorm(300),
            nn.ReLU(),
        )
        self.fc3=nn.Sequential(
            nn.Linear(300,100),
            nn.Dropout(0.5),
            nn.LayerNorm(100),
            nn.ReLU()
        )
        self.dna_fc4=nn.Sequential(
            nn.Linear(100,50),
            nn.Dropout(0.5),
            nn.LayerNorm(50),
            nn.ReLU()
        )

        self.dna_fc5=nn.Linear(50,2)

        self.rna_fc4=nn.Sequential(
            nn.Linear(100,50),
            nn.Dropout(0.5),
            nn.LayerNorm(50),
            nn.ReLU()
        )
        self.rna_fc5=nn.Linear(50,2)

    # batch_size*seq_len*fea_dim
    def forward(self,input):
        lstm_out,(h_,c_)=self.LSTM(input)

        out=self.fc1(lstm_out)
        out = self.fc2(out)
        out = self.fc3(out)

        dna_out = self.dna_fc4(out)
        dna_out = self.dna_fc5(dna_out)

        rna_out = self.rna_fc4(out)
        rna_out = self.rna_fc5(rna_out)
        return dna_out,rna_out

if __name__ == '__main__':
    model=ESM_NBR(1280,100,2)
    model.load_state_dict(torch.load(r"C:\Users\z8049\PycharmProjects\TargetDBP\mutil_label\stand_alone\DRNA_TY17Tst_ESM2_650M_Only.model"))
