import time
import model
import torch
import esm
import os,sys


if len(sys.argv)!=8:
    print("fasta_path:\ndevice:\nsave_dir:\nmodel_type:\nsplit_len:\ndna_threshold:\nrna_threshold:")
    sys.exit()

fasta_path=sys.argv[1]
device=sys.argv[2]
save_dir=sys.argv[3]
model_type=sys.argv[4]
#Long sequences are cut into short sequences to generate ESM feature representations.
split_len=int(sys.argv[5])
dna_threshold=float(sys.argv[6])
rna_threshold=float(sys.argv[7])

if model_type=="YK17":
    model_dicts=torch.load("./YK17.model")
elif model_type=="DRNA1068":
    model_dicts=torch.load("./DRNA1068.model")
else:
    print("model_type should be one of YK17 and DRNA1068!")
    sys.exit()

pred_model=model.ESM_NBR(1280,100,2)
pred_model.load_state_dict(model_dicts)
pred_model.to(device)
pred_model.eval()


def readfastaAndSeq(file_path):
    fi=open(file_path,'r')
    dicts={}

    while True:
        oneLine=fi.readline()
        twoLine=fi.readline()
        if not oneLine:break
        dicts[oneLine[1:-1]]=twoLine[:-1]
    fi.close()
    return dicts


def get_one_protein_esm_fea(protein_name,seq):
    data = [(protein_name, seq)]
    model, alphabet=esm.pretrained.esm2_t33_650M_UR50D()
    batch_converter = alphabet.get_batch_converter()
    batch_labels, batch_strs, batch_tokens = batch_converter(data)
    model.to(device)
    # Extract per-residue representations (on device)
    with torch.no_grad():
        batch_tokens=batch_tokens.to(device)
        #batch*seq_len*fea_dim
        results = model(batch_tokens, repr_layers=[33], return_contacts=True)
        token_representations = torch.squeeze(results["representations"][33])
        return token_representations[1:-1]


def split_if_oom(lens,protein_name,seq):
    res=None
    for i in range(0,len(seq),lens):
        if i + split_len < len(seq):
            new_seq = seq[i:i + split_len]
        else:
            new_seq = seq[i:]
        one_res=get_one_protein_esm_fea(protein_name,new_seq)
        if res is None:
            res=one_res
        else:
            res=torch.cat((res,one_res),dim=0)
    return res


def run_esm_nbr(protein_name,seq):
    print("Begin Run ESM-NBR...")
    print("Protein Name: "+protein_name)
    print("Sequence Length: {0}".format(len(seq)))

    if len(seq)>split_len:
        fea=split_if_oom(split_len,protein_name,seq)
    else:
        fea=get_one_protein_esm_fea(protein_name,seq)
    print("ESM feature generated over...")
    dna_out,rna_out=pred_model(fea)
    dna_out,rna_out=torch.squeeze(dna_out).to('cpu'),torch.squeeze(rna_out).to('cpu')
    dna_out = torch.softmax(dna_out, dim=1)
    rna_out = torch.softmax(rna_out, dim=1)
    return dna_out[:,1],rna_out[:,1]

if __name__ == '__main__':

    begin_time = time.time()
    pro_seq_dict=readfastaAndSeq(fasta_path)
    fi=open(save_dir+os.sep+"ESM-NBR-prediction.res",'w')
    for one_pro,one_seq in zip(pro_seq_dict.keys(),pro_seq_dict.values()):
        dna_pro,rna_pro=run_esm_nbr(one_pro,one_seq)
        fi.write("#"+one_pro+'\n')
        fi.write("AA\tDNA-binding residue probability\tDNA-binding residue result\tRNA-binding residue probability\tRNA-binding residue result\n")
        for one_AA,one_dna_pro,one_rna_pro in zip(one_seq,dna_pro,rna_pro):
            fi.write(one_AA+'\t')
            fi.write(str(one_dna_pro.item())+'\t')
            d_lab='0' if one_dna_pro.item()<dna_threshold else '1'
            fi.write(d_lab+'\t')
            fi.write(str(one_rna_pro.item())+'\t')
            r_lab = '0' if one_rna_pro.item() < rna_threshold else '1'
            fi.write(r_lab + '\t\n')
    fi.close()
    print("Prediction Over! Happy Every Day!")
    sum_time=time.time()-begin_time
    print("The whole prediction process took {0:.2f} seconds.".format(sum_time/10))